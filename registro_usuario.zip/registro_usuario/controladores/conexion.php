<?php
$host_name = 'localhost';
$database = 'registro_usuario';
$user_name = 'root';
$password = '';

$conexion = mysqli_connect($host_name, $user_name, $password, $database);

if(mysqli_errno($conexion)){
    //echo "Error al conectar la base de datos";
}else{
   // echo "Me conecte a la base de datos";
}
$acentos = $conexion -> query("SET NAMES 'utf8'");
?>
